function ApptDetails(){
    return (<div>
        appt deats
            </div>)
} 
export default ApptDetails;